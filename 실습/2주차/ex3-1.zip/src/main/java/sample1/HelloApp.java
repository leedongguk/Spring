package sample1;

public class HelloApp{
	public static void main(String[] args) {
		MessageBean bean = new MessageBean();
		bean.sayHello("Spring");
		}
	}
