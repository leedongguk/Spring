package sample2;

public interface MessageBean{
	void sayHello(String name);
	}
