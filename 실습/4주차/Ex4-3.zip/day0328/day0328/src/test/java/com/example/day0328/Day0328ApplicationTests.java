package com.example.day0328;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day0328ApplicationTests {

	@Test
	void contextLoads() {
	}

}
