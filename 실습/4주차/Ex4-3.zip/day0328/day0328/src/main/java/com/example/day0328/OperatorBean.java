package com.example.day0328;

interface OperatorBean {
    int calc();
}
