package com.example.day0328;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day0328Application {

	public static void main(String[] args) {
		SpringApplication.run(Day0328Application.class, args);
	}

}
