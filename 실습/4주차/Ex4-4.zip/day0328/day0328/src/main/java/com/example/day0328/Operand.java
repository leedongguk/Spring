package com.example.day0328;

public class Operand {
    int value;
    int getValue() {return value;}
    void setValue(int v) { value = v;}
}
