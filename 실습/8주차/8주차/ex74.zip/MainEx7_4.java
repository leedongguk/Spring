package ex74;

import ex74.spring.MemberDao;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainEx7_4 {
    private static MemberDao memberDao;
    public static void main(String[] args) {
        GenericXmlApplicationContext ctx =
                new GenericXmlApplicationContext("classpath:appCtx7_3.xml");
        memberDao = ctx.getBean("memberDao", MemberDao.class);
        System.out.println("Member #: " + memberDao.count());
    }
}
